<!--<?php
sesion_start();
?>
-->
<!DOCTYPE html> 
<html>
	<head>
		<meta charset = "utf-8">
		<title>MIRAVEREDA</title>
	</head>
	<body>
	
	</body>
</html>